from .message import OpenC2Message

__all__ = [
    'OpenC2Message'
]