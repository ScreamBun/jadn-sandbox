from .openc2_wd06_pb2 import OpenC2_Command, OpenC2_Response

__all__ = [
    'OpenC2_Command',
    'OpenC2_Response'
]