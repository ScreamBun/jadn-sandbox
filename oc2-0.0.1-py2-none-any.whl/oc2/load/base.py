import cbor2

from bs4 import BeautifulSoup


class LoadBase(object):
    """
    Translate a JSON Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: Dictionary representation of the message
        :type msg: dict
        :raise TypeError: Dictionary not given
        """
        if type(msg) == dict:
            self._msg = msg

        else:
            raise TypeError('Cannot load message, improperly type given')

    def json_dump(self):
        """
        translate the message to json
        :return: json version of message
        :rtype: dict
        """
        return self._msg

    def protobuf_dump(self):
        """
        translate the message to protobuff
        :return: protobuff version of message
        :rtype: ??
        """
        return self._msg

    def xml_dump(self, pretty=False):
        """
        translate the message to xml
        :param pretty: bool for pretty print
        :return: xml version of message
        :rtype: ??
        """
        xml = BeautifulSoup(features='xml')
        m = xml.new_tag('message')

        for t in self._xml_dump(xml):
            m.append(t)

        xml.append(m)

        return xml.prettify() if pretty else str(xml)

    def _xml_dump(self, s, x=None):
        """
        Recursively translate a dict to xml format
        :param s: BeautifulSoup object to make tags from
        :param x: dict dictionary to translate to xml or use the class _msg var if not set
        :return: xml version of the message
        """
        x = self._msg if x is None else x
        tmp = []

        for k, v in x.items():
            if type(v) in [dict, list]:
                tc = s.new_tag(k)
                for t in self._xml_dump(s, v):
                    tc.append(t)
                tmp.append(tc)
            else:
                t = s.new_tag(k)
                t.string = v
                tmp.append(t)

        return tmp

    def cbor_dump(self):
        """
        translate the message to cbor
        :return: cbor version of message
        :rtype: str
        """
        return ''.join(["\\x{}".format(c.encode('hex')) if ord(c) >= 128 else c for c in cbor2.dumps(self._msg)])
