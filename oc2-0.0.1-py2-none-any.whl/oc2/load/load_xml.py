from bs4 import BeautifulSoup

from .base import LoadBase


class XML(LoadBase):
    """
    Translate a XML Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: XML Encoded message
        :type msg: str
        """
        self._xml = BeautifulSoup(msg, features='xml').findChild('message')
        self._msg = self._xml_to_dict()

        super(XML, self).__init__(self._msg)

    def _xml_to_dict(self, t=None):
        tag = self._xml if t is None else t
        tmp = {}

        for t in tag.findChildren(recursive=False):
            n = unicode(t.name)
            if t.string is None:
                tmp[n] = self._xml_to_dict(t)
            else:
                tmp[n] = unicode(t.string)

        return tmp
