import json
# import ??


class ProtoBuf(object):
    """
    Translate a ProtoBuf Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: ProtoBuf Encoded message
        :type msg: str
        """
        self._msg = msg

    def protobuff_dump(self):
        """
        translate the message to protobuff
        :return: protobuff version of message
        :rtype: ??
        """
        return self._msg

    def xml_dump(self):
        """
        translate the message to xml
        :return: xml version of message
        :rtype: ??
        """
        return self._msg

    def cbor_dump(self):
        """
        translate the message to cbor
        :return: cbor version of message
        :rtype: str
        """
        return self._msg

    def json_dump(self):
        """
        translate the message to json
        :return: json version of message
        :rtype: str
        """
        return self._msg

    def json_dumps(self):
        """
        translate the message to json
        :return: json string version of message
        :rtype: str
        """
        return json.dumps(self.json_dump())
