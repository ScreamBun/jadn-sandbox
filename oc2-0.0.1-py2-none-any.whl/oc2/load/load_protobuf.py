from .base import LoadBase


class ProtoBuf(LoadBase):
    """
    Translate a ProtoBuf Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: ProtoBuf Encoded message
        :type msg: str ??
        """

        self._msg = {}
        super(ProtoBuf, self).__init__(self._msg)
