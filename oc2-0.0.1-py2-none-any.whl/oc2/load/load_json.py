import json


class JSON(object):
    """
    Translate a JSON Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: JSON Encoded message
        :type msg: str or dict
        """
        if type(msg) == str:
            try:
                self._msg = json.loads(msg)
            except (SyntaxError, ValueError) as e:
                raise e

        elif type(msg) == dict:
            self._msg = msg

        else:
            raise Exception('Cannot load json, improperly formatted')

    def json_dump(self):
        """
        translate the message to json
        :return: json version of message
        :rtype: dict
        """
        return self._msg

    def json_dumps(self):
        """
        translate the message to json
        :return: json string version of message
        :rtype: str
        """
        return json.dumps(self._msg)

    def protobuff_dump(self):
        """
        translate the message to protobuff
        :return: protobuff version of message
        :rtype: ??
        """
        return self._msg

    def xml_dump(self):
        """
        translate the message to xml
        :return: xml version of message
        :rtype: ??
        """
        return self._msg

    def cbor_dump(self):
        """
        translate the message to cbor
        :return: cbor version of message
        :rtype: str
        """
        return self._msg