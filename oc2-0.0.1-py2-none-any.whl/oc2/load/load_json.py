import json

from .base import LoadBase


class JSON(LoadBase):
    """
    Translate a JSON Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: JSON Encoded message
        :type msg: str or dict
        :raise SyntaxError: Malformed JSON encoded message
        :raise ValueError: Malformed JSON encoded message
        """
        if type(msg) == str:
            try:
                self._msg = json.loads(msg)
            except (SyntaxError, ValueError) as e:
                raise e

        elif type(msg) == dict:
            self._msg = msg

        else:
            raise Exception('Cannot load json, improperly formatted')

        super(JSON, self).__init__(self._msg)




