import cbor2
import json

from .base import LoadBase


class CBOR(LoadBase):
    """
    Translate a CBOR Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: CBOR Encoded message
        :type msg: unicode
        :raise SyntaxError: Malformed CBOR encoded message
        :raise ValueError: Malformed CBOR encoded message
        :raise cbor2.decoder.CBORDecodeError: Malformed CBOR encoded message
        """
        if type(msg) in [str, unicode]:
            try:
                self._msg = cbor2.loads(msg)
            except (SyntaxError, ValueError, cbor2.decoder.CBORDecodeError) as e:
                print("String improperly formatted, attempting alternative load")
                try:
                    self._msg = cbor2.loads(''.join(["\\x{}".format(c.encode('hex')) if ord(c) > 128 else c for c in msg]))
                except (SyntaxError, ValueError, cbor2.decoder.CBORDecodeError):
                    raise e
        else:
            raise Exception('Cannot load cbor, improperly formatted')

        self._msg = json.loads(json.dumps(self._msg))
        super(CBOR, self).__init__(self._msg)