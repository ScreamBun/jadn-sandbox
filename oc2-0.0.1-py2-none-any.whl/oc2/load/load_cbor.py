import cbor2
import json


class CBOR(object):
    """
    Translate a CBOR Encoded message to other formats
    """
    def __init__(self, msg):
        """
        :param msg: CBOR Encoded message
        :type msg: str
        """
        if type(msg) == str:
            try:
                self._msg = cbor2.loads(msg)
            except (SyntaxError, ValueError) as e:
                raise e
        else:
            raise Exception('Cannot load cbor, improperly formatted')

    def cbor_dump(self):
        """
        translate the message to cbor
        :return: cbor version of message
        :rtype: str
        """
        return cbor2.dumps(self._msg)

    def json_dump(self):
        """
        translate the message to json
        :return: json version of message
        :rtype: dict
        """
        return self._msg

    def json_dumps(self):
        """
        translate the message to json
        :return: json string version of message
        :rtype: str
        """
        return json.dumps(self.json_dump())

    def protobuff_dump(self):
        """
        translate the message to protobuff
        :return: protobuff version of message
        :rtype: ??
        """
        return self._msg

    def xml_dump(self):
        """
        translate the message to xml
        :return: xml version of message
        :rtype: ??
        """
        return self._msg



