from enum import Enum


class OpenC2MessageFormats(Enum):
    JSON = 'json'
    CBOR = 'cbor'
    ProtoBuf = 'protobuf'
    XML = 'xml'