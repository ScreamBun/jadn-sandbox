"""
Make overarching translator/validator class here??
"""