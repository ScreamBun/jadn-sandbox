from .dump import cddl_dump, cddl_dumps
from .load import cddl_load, cddl_loads

__all__ = [
    'cddl_dump',
    'cddl_dumps',
    'cddl_load',
    'cddl_loads'
]