from .html import html_dump, html_dumps

__all__ = [
    'html_dump',
    'html_dumps'
]
